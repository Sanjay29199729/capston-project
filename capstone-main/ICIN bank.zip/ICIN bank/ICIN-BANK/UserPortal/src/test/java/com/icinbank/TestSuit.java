package com.icinbank;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({RegistrationForm.class, AddRecipient.class, Deposit.class, LoginForm.class, Profiledisplay.class, RequestChequebook.class, Withdraw.class, TransferbtwAccounts.class})
public class TestSuit {

}
